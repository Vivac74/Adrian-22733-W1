package org.example;

import com.mycompany.converter.UnitConverter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

public class Main extends JFrame {
    private JTextField inputTextField;
    private JComboBox<String> conversionComboBox;
    private JLabel resultLabel;

    public Main() {
        setTitle("Przelicznik jednostek");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        createUI();
    }

    private void createUI() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;

        JLabel conversionLabel = new JLabel("Konwersja:");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(10, 10, 0, 10);
        panel.add(conversionLabel, constraints);

        String[] conversionOptions = {
                "Kilometry -> Mile",
                "Mile -> Kilometry",
                "Stopnie Celsiusza -> Stopnie Fahrenheita",
                "Stopnie Fahrenheita -> Stopnie Celsiusza",
                "Kilogramy -> Funty",
                "Funty -> Kilogramy"
        };
        conversionComboBox = new JComboBox<>(conversionOptions);
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.insets = new Insets(10, 0, 0, 10);
        panel.add(conversionComboBox, constraints);

        JLabel inputLabel = new JLabel("Wartość:");
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.insets = new Insets(10, 10, 0, 10);
        panel.add(inputLabel, constraints);

        inputTextField = new JTextField();
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.insets = new Insets(10, 0, 0, 10);
        panel.add(inputTextField, constraints);

        JButton convertButton = new JButton("Konwertuj");
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(10, 10, 0, 10);
        panel.add(convertButton, constraints);

        resultLabel = new JLabel();
        resultLabel.setHorizontalAlignment(JLabel.CENTER);
        resultLabel.setFont(new Font("Arial", Font.BOLD, 16));
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(10, 10, 10, 10);
        panel.add(resultLabel, constraints);

        add(panel);

        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convert();
            }
        });
    }

    private void convert()
    {
        double value;
        try {
            value = Double.parseDouble(inputTextField.getText());
        } catch (NumberFormatException e) {
            resultLabel.setText("Nieprawidłowa wartość");
            return;
        }

        String selectedConversion = (String) conversionComboBox.getSelectedItem();
        String resultText;

        DecimalFormat decimalFormat = new DecimalFormat("#.##");

        switch (selectedConversion) {
            case "Kilometry -> Mile":
                double miles = UnitConverter.convertKilometersToMiles(value);
                resultText = decimalFormat.format(miles) + " mil";
                break;
            case "Mile -> Kilometry":
                double kilometers = UnitConverter.convertMilesToKilometers(value);
                resultText = decimalFormat.format(kilometers) + " kilometrów";
                break;
            case "Stopnie Celsiusza -> Stopnie Fahrenheita":
                double fahrenheit = UnitConverter.convertCelsiusToFahrenheit(value);
                resultText = decimalFormat.format(fahrenheit) + " stopni Fahrenheita";
                break;
            case "Stopnie Fahrenheita -> Stopnie Celsiusza":
                double celsius = UnitConverter.convertFahrenheitToCelsius(value);
                resultText = decimalFormat.format(celsius) + " stopni Celsiusza";
                break;
            case "Kilogramy -> Funty":
                double pounds = UnitConverter.convertKilogramsToPounds(value);
                resultText = decimalFormat.format(pounds) + " funtów";
                break;
            case "Funty -> Kilogramy":
                double kilograms = UnitConverter.convertPoundsToKilograms(value);
                resultText = decimalFormat.format(kilograms) + " kilogramów";
                break;
            default:
                resultText = "Nieprawidłowa konwersja";
                break;
        }

        resultLabel.setText(resultText);
        inputTextField.setText("");  // Zerowanie wartości pola tekstowego
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}