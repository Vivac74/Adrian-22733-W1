package com.mycompany.tests;

import com.mycompany.converter.UnitConverter;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class UnitConverterTest
{
    @Test
    public void testConvertKilometersToMiles()
    {
        double kilometers = 10.0;
        double expectedMiles = 6.21;
        double actualMiles = UnitConverter.convertKilometersToMiles(kilometers);
        assertEquals(expectedMiles, actualMiles, 0.01);
    }

    @Test
    public void testConvertMilesToKilometers()
    {
        double miles = 10.0;
        double expectedKilometers = 16.09;
        double actualKilometers = UnitConverter.convertMilesToKilometers(miles);
        assertEquals(expectedKilometers, actualKilometers, 0.01);
    }

    @Test
    public void testConvertCelsiusToFahrenheit()
    {
        double celsius = 25.0;
        double expectedFahrenheit = 77.0;
        double actualFahrenheit = UnitConverter.convertCelsiusToFahrenheit(celsius);
        assertEquals(expectedFahrenheit, actualFahrenheit, 0.01);
    }

    @Test
    public void testConvertFahrenheitToCelsius()
    {
        double fahrenheit = 68.0;
        double expectedCelsius = 20.0;
        double actualCelsius = UnitConverter.convertFahrenheitToCelsius(fahrenheit);
        assertEquals(expectedCelsius, actualCelsius, 0.01);
    }

    @Test
    public void testConvertKilogramsToPounds()
    {
        double kilograms = 10.0;
        double expectedPounds = 22.05;
        double actualPounds = UnitConverter.convertKilogramsToPounds(kilograms);
        assertEquals(expectedPounds, actualPounds, 0.01);
    }

    @Test
    public void testConvertPoundsToKilograms()
    {
        double pounds = 10.0;
        double expectedKilograms = 4.54;
        double actualKilograms = UnitConverter.convertPoundsToKilograms(pounds);
        assertEquals(expectedKilograms, actualKilograms, 0.01);
    }
}