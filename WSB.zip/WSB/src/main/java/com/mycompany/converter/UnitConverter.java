package com.mycompany.converter;

import org.apache.commons.math3.util.Precision;

public class UnitConverter
{
    // Konwersja kilometrów na mile
    public static double convertKilometersToMiles(double kilometers)
    {
        double miles = kilometers * 0.621371;
        return Precision.round(miles, 2); // Zaokrąglenie do 2 miejsc po przecinku
    }

    // Konwersja mil na kilometry
    public static double convertMilesToKilometers(double miles)
    {
        double kilometers = miles / 0.621371;
        return Precision.round(kilometers, 2); // Zaokrąglenie do 2 miejsc po przecinku
    }

    // Konwersja stopni Celsiusza na stopnie Fahrenheita
    public static double convertCelsiusToFahrenheit(double celsius)
    {
        double fahrenheit = (celsius * 9/5) + 32;
        return Precision.round(fahrenheit, 2);
    }

    // Konwersja stopni Fahrenheita na stopnie Celsiusza
    public static double convertFahrenheitToCelsius(double fahrenheit)
    {
        double celsius = (fahrenheit - 32) * 5/9;
        return Precision.round(celsius, 2);
    }

    // Konwersja kilogramów na funty
    public static double convertKilogramsToPounds(double kilograms)
    {
        double pounds = kilograms * 2.20462;
        return Precision.round(pounds, 2);
    }

    // Konwersja funtów na kilogramy
    public static double convertPoundsToKilograms(double pounds)
    {
        double kilograms = pounds / 2.20462;
        return Precision.round(kilograms, 2);
    }
}